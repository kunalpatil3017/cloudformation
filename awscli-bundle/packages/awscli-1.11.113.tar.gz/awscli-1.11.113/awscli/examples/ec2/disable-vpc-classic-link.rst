**To disable ClassicLink for a VPC**

This example disables ClassicLink for vpc-8888888.

Command::

  aws ec2 disable-vpc-classic-link --vpc-id vpc-88888888

Output::

  {
    "Return": true
  }